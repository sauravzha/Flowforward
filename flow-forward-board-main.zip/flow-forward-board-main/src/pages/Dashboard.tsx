
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { 
  CheckCircle, MessageCircle, FileText, Calendar, 
  Sparkles, Clock, BarChart, FileInput
} from "lucide-react";

interface ModuleCardProps {
  title: string;
  icon: React.ReactNode;
  bgColor: string;
  route: string;
}

const Dashboard = () => {
  const navigate = useNavigate();

  const modules = [
    { title: "Tasks", icon: <CheckCircle className="h-8 w-8" />, bgColor: "bg-emerald-500", route: "/dashboard/tasks" },
    { title: "Chat", icon: <MessageCircle className="h-8 w-8" />, bgColor: "bg-blue-500", route: "/dashboard/chat" },
    { title: "Docs", icon: <FileText className="h-8 w-8" />, bgColor: "bg-indigo-500", route: "/dashboard/docs" },
    { title: "Calendar", icon: <Calendar className="h-8 w-8" />, bgColor: "bg-amber-500", route: "/dashboard/calendar" },
    { title: "AI", icon: <Sparkles className="h-8 w-8" />, bgColor: "bg-purple-500", route: "/dashboard/ai" },
    { title: "Time Tracking", icon: <Clock className="h-8 w-8" />, bgColor: "bg-pink-500", route: "/dashboard/time-tracking" },
    { title: "Dashboards", icon: <BarChart className="h-8 w-8" />, bgColor: "bg-cyan-500", route: "/dashboard/dashboards" },
    { title: "Forms", icon: <FileInput className="h-8 w-8" />, bgColor: "bg-teal-500", route: "/dashboard/forms" },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const ModuleCard = ({ title, icon, bgColor, route }: ModuleCardProps) => (
    <motion.div 
      variants={item}
      className="col-span-1"
      whileHover={{ scale: 1.05, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }}
      onClick={() => navigate(route)}
    >
      <div className={`rounded-xl shadow-lg overflow-hidden cursor-pointer h-full`}>
        <div className={`${bgColor} text-white p-6`}>
          {icon}
        </div>
        <div className="p-6 bg-white dark:bg-gray-800">
          <h3 className="text-lg font-semibold">{title}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
            Manage your {title.toLowerCase()} efficiently
          </p>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Welcome to FlowForward</h1>
          <p className="mt-3 text-xl text-gray-600 dark:text-gray-300">
            Your all-in-one workspace for productivity
          </p>
        </motion.div>

        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {modules.map((module, index) => (
            <ModuleCard
              key={index}
              title={module.title}
              icon={module.icon}
              bgColor={module.bgColor}
              route={module.route}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
