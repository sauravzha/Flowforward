
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { useBoardStore } from "@/store/boardStore";
import BoardList from "@/components/BoardList";
import { Plus, Settings, ArrowLeft, MoreHorizontal, Edit2 } from "lucide-react";
import {
  DndContext,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent,
  DragOverEvent
} from '@dnd-kit/core';

const Board = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { boards, setActiveBoard, activeBoard, addList, moveCard } = useBoardStore();
  const [isAddingList, setIsAddingList] = useState(false);
  const [newListName, setNewListName] = useState("");
  const [activeCardId, setActiveCardId] = useState<string | null>(null);
  const [activeListId, setActiveListId] = useState<string | null>(null);
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  useEffect(() => {
    if (id) {
      setActiveBoard(id);
    }
  }, [id, setActiveBoard]);

  const handleAddList = () => {
    if (newListName.trim() && id) {
      addList(id, newListName);
      setNewListName("");
      setIsAddingList(false);
    }
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    setActiveCardId(active.id as string);
    
    // Find the list containing the card
    let sourceListId: string | null = null;
    
    activeBoard?.lists.forEach(list => {
      if (list.cards.some(card => card.id === active.id)) {
        sourceListId = list.id;
      }
    });
    
    setActiveListId(sourceListId);
  };

  const handleDragOver = (event: DragOverEvent) => {
    // Optional: Handle any hover effects or calculations
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id && id && activeListId) {
      // Get the destination list ID from the over ID
      // This assumes your over ID includes or is the list ID
      // You may need to adjust based on your actual ID structure
      const destinationListId = over.id as string;
      
      // Move the card
      moveCard(id, activeListId, destinationListId, active.id as string);
    }
    
    setActiveCardId(null);
    setActiveListId(null);
  };

  if (!activeBoard) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-white mb-4">Board not found</h2>
          <button
            onClick={() => navigate("/dashboard/tasks")}
            className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
          >
            Back to Tasks
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 py-6 px-4">
      <div className="max-w-screen-2xl mx-auto">
        <div className="mb-6 flex justify-between items-center">
          <div className="flex items-center">
            <button 
              onClick={() => navigate("/dashboard/tasks")}
              className="mr-4 p-2 bg-white dark:bg-gray-800 rounded-full shadow-sm hover:shadow-md transition-shadow"
            >
              <ArrowLeft size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{activeBoard.name}</h1>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-sm hover:shadow-md transition-shadow">
              <Settings size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
            <button className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-sm hover:shadow-md transition-shadow">
              <MoreHorizontal size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
          </div>
        </div>

        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          <div className="flex space-x-4 overflow-x-auto pb-6 pt-2 px-2">
            {activeBoard.lists.map((list) => (
              <BoardList key={list.id} list={list} boardId={id || ""} />
            ))}
            
            {isAddingList ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md w-72 shrink-0 p-3">
                <input
                  type="text"
                  placeholder="Enter list title..."
                  value={newListName}
                  onChange={(e) => setNewListName(e.target.value)}
                  className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent"
                  autoFocus
                />
                <div className="flex justify-end space-x-2 mt-3">
                  <button
                    onClick={() => setIsAddingList(false)}
                    className="px-3 py-1 text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddList}
                    className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
                  >
                    Add List
                  </button>
                </div>
              </div>
            ) : (
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setIsAddingList(true)}
                className="bg-white/80 dark:bg-gray-800/90 rounded-lg shadow-sm hover:shadow-md w-72 shrink-0 h-16 flex items-center justify-center text-gray-600 dark:text-gray-300 border-2 border-dashed border-gray-300 dark:border-gray-700"
              >
                <Plus size={20} className="mr-2" />
                <span>Add a list</span>
              </motion.button>
            )}
          </div>
          
          {/* Drag overlay for the currently dragged card */}
          <DragOverlay>
            {activeCardId && activeBoard.lists.flatMap(list => 
              list.cards.filter(card => card.id === activeCardId)
            ).map(card => (
              <div 
                key={card.id}
                className="bg-white dark:bg-gray-700 p-3 rounded-md shadow-lg w-64"
              >
                <h4 className="font-medium text-gray-800 dark:text-white mb-1">{card.title}</h4>
                {card.description && (
                  <p className="text-gray-600 dark:text-gray-300 text-sm line-clamp-2">{card.description}</p>
                )}
              </div>
            ))}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  );
};

export default Board;
