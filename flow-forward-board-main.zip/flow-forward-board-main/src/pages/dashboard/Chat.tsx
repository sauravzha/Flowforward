
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Send, User, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'other';
  timestamp: Date;
}

const Chat = () => {
  const navigate = useNavigate();
  const [inputMessage, setInputMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: "Hi there! How can I help you today?", sender: 'other', timestamp: new Date(Date.now() - 3600000) },
    { id: 2, text: "I need help with my project timeline.", sender: 'user', timestamp: new Date(Date.now() - 3500000) },
    { id: 3, text: "Sure, I can help with that. Could you share more details about your project?", sender: 'other', timestamp: new Date(Date.now() - 3400000) },
  ]);

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: inputMessage,
        sender: 'user',
        timestamp: new Date(),
      };
      
      setMessages([...messages, newMessage]);
      setInputMessage("");
      
      // Simulate response after a short delay
      setTimeout(() => {
        const responseMessage: Message = {
          id: messages.length + 2,
          text: "I've received your message. Let me get back to you shortly.",
          sender: 'other',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, responseMessage]);
      }, 1000);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Chat</h1>
        <h2 className="text-lg text-blue-600 dark:text-blue-400 font-medium mb-8">
          Manage your chat efficiently
        </h2>

        <Card className="h-[70vh] flex flex-col">
          <CardContent className="flex flex-col h-full p-0">
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div 
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === 'user' 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white'
                    }`}
                  >
                    <div className="flex items-center mb-1">
                      {message.sender === 'user' ? (
                        <User size={16} className="mr-1" />
                      ) : (
                        <MessageCircle size={16} className="mr-1" />
                      )}
                      <span className="text-xs">
                        {message.sender === 'user' ? 'You' : 'Team Member'}
                      </span>
                      <span className="text-xs ml-auto">
                        {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                    </div>
                    <p className="text-sm">{message.text}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-200 p-4 bg-white dark:bg-gray-800">
              <div className="flex gap-2">
                <Textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message..."
                  className="flex-1 resize-none"
                  rows={2}
                />
                <Button 
                  onClick={handleSendMessage}
                  className="self-end bg-blue-500 hover:bg-blue-600"
                >
                  <Send size={18} />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Chat;
