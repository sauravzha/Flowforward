
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const Forms = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-lg w-full bg-white dark:bg-gray-800 rounded-xl shadow-md p-8">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 text-center">Forms</h1>
        <h2 className="text-lg text-teal-600 dark:text-teal-400 font-medium text-center mb-4">
          Manage your forms efficiently
        </h2>
        <ul className="text-gray-700 dark:text-gray-300 space-y-2 text-center">
          <li>📥 Create forms to collect feedback and submissions.</li>
          <li>🗂️ Organize and review your form data with ease.</li>
          <li>🤖 Automate data flows from your forms into your workflow.</li>
        </ul>
      </div>
    </div>
  );
};

export default Forms;
