
import { useNavigate } from "react-router-dom";
import { ArrowLeft, CalendarDays } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const CalendarPage = () => {
  const navigate = useNavigate();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [events] = useState([
    { date: new Date(2025, 3, 20), title: "Team Meeting", description: "Discuss project timeline" },
    { date: new Date(2025, 3, 22), title: "Client Presentation", description: "Present project proposal" },
    { date: new Date(2025, 3, 25), title: "Deadline", description: "Submit final version" },
  ]);

  const selectedDateEvents = events.filter(
    (event) => date && event.date.toDateString() === date.toDateString()
  );

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Calendar</h1>
        <h2 className="text-lg text-amber-600 dark:text-amber-400 font-medium mb-8">
          Manage your calendar efficiently
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-7 lg:col-span-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CalendarDays className="mr-2" /> 
                  Calendar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="border-none mx-auto"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-5 lg:col-span-4">
            <Card>
              <CardHeader>
                <CardTitle>
                  {date ? date.toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  }) : "Select a date"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDateEvents.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateEvents.map((event, index) => (
                      <div key={index} className="border-l-4 border-amber-500 pl-4 py-2">
                        <h3 className="font-semibold">{event.title}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{event.description}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 dark:text-gray-400">No events scheduled for this day</p>
                )}
                <button className="mt-4 w-full bg-amber-600 hover:bg-amber-700 text-white py-2 px-4 rounded-md transition-colors">
                  Add New Event
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarPage;
