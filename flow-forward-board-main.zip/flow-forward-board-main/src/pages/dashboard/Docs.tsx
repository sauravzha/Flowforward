
import { useNavigate } from "react-router-dom";
import { ArrowLeft, FileText, PlusCircle, Search, Star, Clock, Users, FolderOpen } from "lucide-react";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Document {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  createdAt: Date;
  starred: boolean;
}

const Docs = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: 1,
      title: "Project Overview",
      excerpt: "This document outlines the main goals, timeline, and team members for our Q2 website redesign project.",
      category: "Projects",
      createdAt: new Date(2025, 3, 15),
      starred: true
    },
    {
      id: 2,
      title: "Meeting Notes: Kickoff",
      excerpt: "Notes from our project kickoff meeting including action items and decisions made.",
      category: "Meetings",
      createdAt: new Date(2025, 3, 16),
      starred: false
    },
    {
      id: 3,
      title: "Design Guidelines",
      excerpt: "Comprehensive guidelines for design elements, including colors, typography, and component specifications.",
      category: "Design",
      createdAt: new Date(2025, 3, 18),
      starred: true
    },
    {
      id: 4,
      title: "API Documentation",
      excerpt: "Technical documentation for the RESTful API endpoints used in the application.",
      category: "Development",
      createdAt: new Date(2025, 3, 19),
      starred: false
    },
  ]);

  const categories = [
    { id: 1, name: "All Documents", icon: <FileText size={18} /> },
    { id: 2, name: "Starred", icon: <Star size={18} /> },
    { id: 3, name: "Recent", icon: <Clock size={18} /> },
    { id: 4, name: "Shared with me", icon: <Users size={18} /> },
    { id: 5, name: "Projects", icon: <FolderOpen size={18} /> },
    { id: 6, name: "Meetings", icon: <FolderOpen size={18} /> },
    { id: 7, name: "Design", icon: <FolderOpen size={18} /> },
    { id: 8, name: "Development", icon: <FolderOpen size={18} /> },
  ];

  const toggleStar = (id: number) => {
    setDocuments(documents.map(doc => 
      doc.id === id ? { ...doc, starred: !doc.starred } : doc
    ));
  };

  const filteredDocuments = documents.filter(doc => 
    doc.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    doc.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Docs</h1>
        <h2 className="text-lg text-indigo-600 dark:text-indigo-400 font-medium mb-8">
          Manage your docs efficiently
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <Button 
                  className="w-full mb-4 bg-indigo-600 hover:bg-indigo-700"
                >
                  <PlusCircle size={16} className="mr-2" />
                  New Document
                </Button>
              </CardHeader>
              <CardContent className="p-2">
                <nav>
                  <ul className="space-y-1">
                    {categories.map(category => (
                      <li key={category.id}>
                        <button className="w-full text-left px-3 py-2 rounded-md flex items-center hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                          <span className="text-gray-500 dark:text-gray-400 mr-3">
                            {category.icon}
                          </span>
                          <span>{category.name}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </nav>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Card>
              <CardHeader className="pb-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="text"
                    placeholder="Search documents..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredDocuments.length > 0 ? (
                    filteredDocuments.map(doc => (
                      <div 
                        key={doc.id}
                        className="flex items-start border-b border-gray-200 dark:border-gray-700 pb-4"
                      >
                        <div className="mr-3 mt-1">
                          <FileText className="text-indigo-500" size={20} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                              {doc.title}
                            </h3>
                            <button 
                              onClick={() => toggleStar(doc.id)}
                              className="focus:outline-none"
                            >
                              <Star
                                size={18}
                                className={doc.starred ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
                              />
                            </button>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {doc.excerpt}
                          </p>
                          <div className="flex items-center mt-2 text-xs text-gray-500 dark:text-gray-400">
                            <span className="mr-4">{doc.category}</span>
                            <span>Created on {doc.createdAt.toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                      No documents found. Try a different search term.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Docs;
