
import { useNavigate } from "react-router-dom";
import { ArrowLeft, BarChart, LineChart, PieChart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart as RechartsBarChart, XAxis, YAxis, Tooltip, Legend, Bar, ResponsiveContainer, CartesianGrid, LineChart as RechartsLineChart, Line } from "recharts";

const Dashboards = () => {
  const navigate = useNavigate();

  const projectData = [
    { name: 'Jan', completed: 45, pending: 25, total: 70 },
    { name: 'Feb', completed: 55, pending: 20, total: 75 },
    { name: 'Mar', completed: 60, pending: 30, total: 90 },
    { name: 'Apr', completed: 75, pending: 15, total: 90 },
    { name: 'May', completed: 85, pending: 10, total: 95 },
    { name: 'Jun', completed: 70, pending: 25, total: 95 },
  ];

  const teamPerformance = [
    { name: 'Team A', value: 400 },
    { name: 'Team B', value: 300 },
    { name: 'Team C', value: 500 },
    { name: 'Team D', value: 280 },
    { name: 'Team E', value: 590 },
  ];

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Dashboards</h1>
        <h2 className="text-lg text-cyan-600 dark:text-cyan-400 font-medium mb-8">
          Manage your dashboards efficiently
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium">
                <BarChart className="h-4 w-4 inline mr-2" />
                Project Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer 
                config={{
                  completed: { theme: { light: "#0ea5e9", dark: "#38bdf8" } },
                  pending: { theme: { light: "#f97316", dark: "#fb923c" } },
                  total: { theme: { light: "#8b5cf6", dark: "#a78bfa" } }
                }}
                className="h-80"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsBarChart data={projectData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Bar dataKey="completed" stackId="a" fill="var(--color-completed)" name="Completed Tasks" />
                    <Bar dataKey="pending" stackId="a" fill="var(--color-pending)" name="Pending Tasks" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium">
                <LineChart className="h-4 w-4 inline mr-2" />
                Team Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer 
                config={{
                  value: { theme: { light: "#8b5cf6", dark: "#a78bfa" } }
                }}
                className="h-80"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={teamPerformance}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip content={<ChartTooltipContent />} />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="var(--color-value)" 
                      strokeWidth={2}
                      activeDot={{ r: 8 }}
                      name="Productivity Score"
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end">
          <button className="bg-cyan-600 hover:bg-cyan-700 text-white font-medium py-2 px-4 rounded-md transition-colors">
            Create New Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboards;
