
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Sparkles, Send } from "lucide-react";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface AiResponse {
  id: number;
  query: string;
  response: string;
  timestamp: Date;
}

const Ai = () => {
  const navigate = useNavigate();
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [responses, setResponses] = useState<AiResponse[]>([
    {
      id: 1,
      query: "Generate a project timeline for website redesign",
      response: "Here's a suggested timeline for your website redesign project:\n\n1. Week 1-2: Research & Discovery\n- Competitor analysis\n- User interviews\n- Content audit\n\n2. Week 3-4: Planning & Design\n- Information architecture\n- Wireframing\n- Visual design concepts\n\n3. Week 5-6: Development\n- Frontend coding\n- CMS integration\n- Responsive implementation\n\n4. Week 7: Testing & Refinement\n- QA testing\n- Performance optimization\n- Content population\n\n5. Week 8: Launch & Follow-up\n- Site deployment\n- Analytics setup\n- Post-launch monitoring",
      timestamp: new Date(Date.now() - 86400000)
    }
  ]);

  const aiTools = [
    { id: 1, name: "Content Generator", description: "Generate blog posts, product descriptions, and more", icon: "📝" },
    { id: 2, name: "Data Analyzer", description: "Get insights from your project data", icon: "📊" },
    { id: 3, name: "Code Assistant", description: "Debug and optimize your code", icon: "💻" },
    { id: 4, name: "Meeting Summarizer", description: "Create concise summaries from meeting transcripts", icon: "📋" },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    
    setIsLoading(true);
    
    // Simulate AI processing
    setTimeout(() => {
      const newResponse: AiResponse = {
        id: responses.length + 1,
        query: prompt,
        response: generateMockResponse(prompt),
        timestamp: new Date()
      };
      
      setResponses([newResponse, ...responses]);
      setPrompt("");
      setIsLoading(false);
    }, 1500);
  };

  const generateMockResponse = (query: string): string => {
    // Simple mock response logic
    if (query.toLowerCase().includes("timeline") || query.toLowerCase().includes("schedule")) {
      return "Based on your requirements, I recommend the following timeline:\n\n" +
        "1. Planning Phase: 2 weeks\n" +
        "2. Design Phase: 3 weeks\n" +
        "3. Development: 4 weeks\n" +
        "4. Testing: 2 weeks\n" +
        "5. Deployment: 1 week\n\n" +
        "Total project duration: 12 weeks";
    } else if (query.toLowerCase().includes("idea") || query.toLowerCase().includes("suggestion")) {
      return "Here are some ideas based on your request:\n\n" +
        "1. Implement a user feedback system\n" +
        "2. Create an automated reporting dashboard\n" +
        "3. Develop a mobile-friendly interface\n" +
        "4. Add data visualization components\n" +
        "5. Integrate with third-party productivity tools";
    } else {
      return "I've analyzed your request and here are my thoughts:\n\n" +
        "Your question touches on some interesting aspects of project management. " +
        "I would recommend focusing on clear communication channels, well-defined milestones, " +
        "and regular progress updates to ensure successful execution. " +
        "Would you like me to elaborate on any specific area?";
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">AI</h1>
        <h2 className="text-lg text-purple-600 dark:text-purple-400 font-medium mb-8">
          Manage your AI efficiently
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Sparkles className="mr-2 text-purple-500" size={18} />
                AI Tools
              </h3>
              <div className="space-y-4">
                {aiTools.map(tool => (
                  <div 
                    key={tool.id} 
                    className="p-3 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-purple-50 dark:hover:bg-gray-700 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center">
                      <span className="text-xl mr-2">{tool.icon}</span>
                      <div>
                        <h4 className="font-medium text-sm">{tool.name}</h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{tool.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Sparkles className="mr-2 text-purple-500" size={18} />
                  AI Assistant
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit}>
                  <div className="flex flex-col gap-4">
                    <Textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder="Ask the AI for help with your tasks, projects, or to generate content..."
                      className="min-h-[100px] resize-none"
                    />
                    <div className="flex justify-end">
                      <Button 
                        type="submit" 
                        className="bg-purple-600 hover:bg-purple-700"
                        disabled={isLoading || !prompt.trim()}
                      >
                        {isLoading ? "Processing..." : "Ask AI"}
                        <Send size={16} className="ml-2" />
                      </Button>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {responses.map((item) => (
                <Card key={item.id}>
                  <CardContent className="pt-6">
                    <div className="mb-3">
                      <div className="font-medium text-gray-800 dark:text-gray-200">{item.query}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {item.timestamp.toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-purple-50 dark:bg-gray-700 p-4 rounded-md whitespace-pre-line">
                      {item.response}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ai;
