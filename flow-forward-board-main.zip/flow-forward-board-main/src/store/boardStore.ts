
import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';

export interface Card {
  id: string;
  title: string;
  description: string;
  dueDate: string;
}

export interface List {
  id: string;
  name: string;
  cards: Card[];
}

export interface Board {
  id: string;
  name: string;
  lists: List[];
}

interface BoardState {
  boards: Board[];
  activeBoard: Board | null;
  setActiveBoard: (boardId: string) => void;
  addBoard: (name: string) => void;
  addList: (boardId: string, name: string) => void;
  removeList: (boardId: string, listId: string) => void;
  renameList: (boardId: string, listId: string, newName: string) => void;
  addCard: (boardId: string, listId: string, card: Omit<Card, 'id'>) => void;
  updateCard: (boardId: string, listId: string, card: Card) => void;
  removeCard: (boardId: string, listId: string, cardId: string) => void;
  moveCard: (
    boardId: string,
    fromListId: string, 
    toListId: string, 
    cardId: string
  ) => void;
}

// Sample data
const initialBoards: Board[] = [
  {
    id: "1",
    name: "Project Launch",
    lists: [
      {
        id: "list-1",
        name: "To Do",
        cards: [
          {
            id: "card-1",
            title: "Design login screen",
            description: "Create Figma wireframes",
            dueDate: "2025-04-22"
          },
          {
            id: "card-2",
            title: "Write API for auth",
            description: "Using JWT or NextAuth",
            dueDate: "2025-04-24"
          }
        ]
      },
      {
        id: "list-2",
        name: "In Progress",
        cards: [
          {
            id: "card-3",
            title: "Set up MongoDB schema",
            description: "Board, List, Card models",
            dueDate: "2025-04-21"
          }
        ]
      },
      {
        id: "list-3",
        name: "Done",
        cards: [
          {
            id: "card-4",
            title: "Initialize project",
            description: "Set up Next.js with Tailwind",
            dueDate: "2025-04-20"
          }
        ]
      }
    ]
  },
  {
    id: "2",
    name: "Personal Goals",
    lists: [
      {
        id: "list-4",
        name: "Learning",
        cards: [
          {
            id: "card-5",
            title: "Learn TypeScript",
            description: "Complete online course",
            dueDate: "2025-05-15"
          }
        ]
      },
      {
        id: "list-5",
        name: "Activities",
        cards: [
          {
            id: "card-6",
            title: "Daily exercise",
            description: "30 minutes workout",
            dueDate: "2025-04-22"
          }
        ]
      }
    ]
  }
];

export const useBoardStore = create<BoardState>((set) => ({
  boards: initialBoards,
  activeBoard: initialBoards[0],
  
  setActiveBoard: (boardId) => set((state) => {
    const board = state.boards.find(b => b.id === boardId) || null;
    return { activeBoard: board };
  }),

  addBoard: (name) => set((state) => {
    const newBoard = {
      id: uuidv4(),
      name,
      lists: []
    };
    return { boards: [...state.boards, newBoard] };
  }),

  addList: (boardId, name) => set((state) => {
    const newList = {
      id: uuidv4(),
      name,
      cards: []
    };
    
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: [...board.lists, newList]
        };
      }
      return board;
    });
    
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: [...state.activeBoard.lists, newList]
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  }),

  removeList: (boardId, listId) => set((state) => {
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: board.lists.filter(list => list.id !== listId)
        };
      }
      return board;
    });
    
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: state.activeBoard.lists.filter(list => list.id !== listId)
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  }),

  renameList: (boardId, listId, newName) => set((state) => {
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: board.lists.map(list => 
            list.id === listId ? { ...list, name: newName } : list
          )
        };
      }
      return board;
    });
    
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: state.activeBoard.lists.map(list => 
              list.id === listId ? { ...list, name: newName } : list
            )
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  }),

  addCard: (boardId, listId, card) => set((state) => {
    const newCard = {
      ...card,
      id: uuidv4()
    };
    
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: board.lists.map(list => {
            if (list.id === listId) {
              return {
                ...list,
                cards: [...list.cards, newCard]
              };
            }
            return list;
          })
        };
      }
      return board;
    });
    
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: state.activeBoard.lists.map(list => {
              if (list.id === listId) {
                return {
                  ...list,
                  cards: [...list.cards, newCard]
                };
              }
              return list;
            })
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  }),

  updateCard: (boardId, listId, updatedCard) => set((state) => {
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: board.lists.map(list => {
            if (list.id === listId) {
              return {
                ...list,
                cards: list.cards.map(card => 
                  card.id === updatedCard.id ? updatedCard : card
                )
              };
            }
            return list;
          })
        };
      }
      return board;
    });
    
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: state.activeBoard.lists.map(list => {
              if (list.id === listId) {
                return {
                  ...list,
                  cards: list.cards.map(card => 
                    card.id === updatedCard.id ? updatedCard : card
                  )
                };
              }
              return list;
            })
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  }),

  removeCard: (boardId, listId, cardId) => set((state) => {
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: board.lists.map(list => {
            if (list.id === listId) {
              return {
                ...list,
                cards: list.cards.filter(card => card.id !== cardId)
              };
            }
            return list;
          })
        };
      }
      return board;
    });
    
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: state.activeBoard.lists.map(list => {
              if (list.id === listId) {
                return {
                  ...list,
                  cards: list.cards.filter(card => card.id !== cardId)
                };
              }
              return list;
            })
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  }),

  moveCard: (boardId, fromListId, toListId, cardId) => set((state) => {
    // Find the card to move
    let cardToMove: Card | undefined;
    
    state.boards.forEach(board => {
      if (board.id === boardId) {
        board.lists.forEach(list => {
          if (list.id === fromListId) {
            cardToMove = list.cards.find(card => card.id === cardId);
          }
        });
      }
    });
    
    if (!cardToMove) return state;
    
    // Create updated boards with the card moved
    const updatedBoards = state.boards.map(board => {
      if (board.id === boardId) {
        return {
          ...board,
          lists: board.lists.map(list => {
            // Remove card from source list
            if (list.id === fromListId) {
              return {
                ...list,
                cards: list.cards.filter(card => card.id !== cardId)
              };
            }
            // Add card to destination list
            if (list.id === toListId) {
              return {
                ...list,
                cards: [...list.cards, cardToMove!]
              };
            }
            return list;
          })
        };
      }
      return board;
    });
    
    // Update active board if needed
    const updatedActiveBoard = 
      state.activeBoard && state.activeBoard.id === boardId
        ? {
            ...state.activeBoard,
            lists: state.activeBoard.lists.map(list => {
              // Remove card from source list
              if (list.id === fromListId) {
                return {
                  ...list,
                  cards: list.cards.filter(card => card.id !== cardId)
                };
              }
              // Add card to destination list
              if (list.id === toListId) {
                return {
                  ...list,
                  cards: [...list.cards, cardToMove!]
                };
              }
              return list;
            })
          }
        : state.activeBoard;
        
    return { 
      boards: updatedBoards,
      activeBoard: updatedActiveBoard
    };
  })
}));
