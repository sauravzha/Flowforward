
import { useState } from "react";
import { motion } from "framer-motion";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Card, useBoardStore } from "@/store/boardStore";
import { Clock, Edit2, Trash2, X, Check } from "lucide-react";

interface CardItemProps {
  card: Card;
  listId: string;
  boardId: string;
}

const CardItem = ({ card, listId, boardId }: CardItemProps) => {
  const { updateCard, removeCard } = useBoardStore();
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(card.title);
  const [description, setDescription] = useState(card.description);
  const [dueDate, setDueDate] = useState(card.dueDate);
  
  const { 
    attributes, 
    listeners, 
    setNodeRef, 
    transform, 
    transition,
    isDragging
  } = useSortable({ id: card.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 10 : 1,
  };

  const handleUpdate = () => {
    if (title.trim()) {
      updateCard(boardId, listId, {
        ...card,
        title,
        description,
        dueDate
      });
      setIsEditing(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { 
      month: "short", 
      day: "numeric" 
    });
  };

  const isOverdue = (dateString: string) => {
    const dueDate = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return dueDate < today;
  };

  if (isEditing) {
    return (
      <motion.div 
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        className="bg-white dark:bg-gray-700 p-3 rounded-md shadow mb-2"
      >
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full mb-2 p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent"
          autoFocus
        />
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full mb-2 p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent resize-none"
          rows={3}
        />
        <div className="mb-3">
          <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">Due Date</label>
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent"
          />
        </div>
        <div className="flex justify-end space-x-2">
          <button
            onClick={() => setIsEditing(false)}
            className="flex items-center px-3 py-1 text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
          >
            <X size={16} className="mr-1" />
            Cancel
          </button>
          <button
            onClick={handleUpdate}
            className="flex items-center px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            <Check size={16} className="mr-1" />
            Save
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      whileHover={{ scale: 1.02 }}
      className="bg-white dark:bg-gray-700 p-3 rounded-md shadow mb-2 cursor-grab active:cursor-grabbing"
    >
      <div className="flex justify-between items-start">
        <h4 className="font-medium text-gray-800 dark:text-white mb-1">{card.title}</h4>
        <div className="flex space-x-1">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              setIsEditing(true);
            }}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1"
          >
            <Edit2 size={14} />
          </button>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              removeCard(boardId, listId, card.id);
            }}
            className="text-gray-400 hover:text-red-500 p-1"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>
      
      {card.description && (
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">{card.description}</p>
      )}
      
      {card.dueDate && (
        <div className={`flex items-center text-xs ${
          isOverdue(card.dueDate) ? 'text-red-500' : 'text-gray-500 dark:text-gray-400'
        }`}>
          <Clock size={12} className="mr-1" />
          <span>{formatDate(card.dueDate)}</span>
        </div>
      )}
    </motion.div>
  );
};

export default CardItem;
