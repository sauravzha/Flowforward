
import { useState } from "react";
import { motion } from "framer-motion";
import { List, useBoardStore, Card as CardType } from "@/store/boardStore";
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import CardItem from "./CardItem";
import { Plus, X, MoreHorizontal, Edit2 } from "lucide-react";

interface BoardListProps {
  list: List;
  boardId: string;
}

const BoardList = ({ list, boardId }: BoardListProps) => {
  const { addCard, removeList, renameList } = useBoardStore();
  const [isAdding, setIsAdding] = useState(false);
  const [newCardTitle, setNewCardTitle] = useState("");
  const [newCardDescription, setNewCardDescription] = useState("");
  const [newCardDueDate, setNewCardDueDate] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [listName, setListName] = useState(list.name);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleAddCard = () => {
    if (newCardTitle.trim()) {
      addCard(boardId, list.id, {
        title: newCardTitle,
        description: newCardDescription,
        dueDate: newCardDueDate || new Date().toISOString().split('T')[0]
      });
      setNewCardTitle("");
      setNewCardDescription("");
      setNewCardDueDate("");
      setIsAdding(false);
    }
  };

  const handleRenameList = () => {
    if (listName.trim()) {
      renameList(boardId, list.id, listName);
      setIsEditing(false);
      setIsMenuOpen(false);
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      // Handle drag end logic if needed
    }
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-800 rounded-lg shadow-md w-72 shrink-0 flex flex-col max-h-full">
      <div className="p-3 flex items-center justify-between bg-white dark:bg-gray-700 rounded-t-lg border-b dark:border-gray-600">
        {isEditing ? (
          <input
            type="text"
            value={listName}
            onChange={(e) => setListName(e.target.value)}
            onBlur={handleRenameList}
            onKeyDown={(e) => e.key === 'Enter' && handleRenameList()}
            className="flex-1 bg-transparent border border-blue-400 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
            autoFocus
          />
        ) : (
          <h3 className="font-medium text-gray-800 dark:text-white">{list.name}</h3>
        )}
        
        <div className="relative">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <MoreHorizontal size={16} />
          </button>
          
          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border dark:border-gray-700">
              <div className="py-1">
                <button
                  onClick={() => {
                    setIsEditing(true);
                    setIsMenuOpen(false);
                  }}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <Edit2 size={16} className="mr-2" />
                  Rename List
                </button>
                <button
                  onClick={() => removeList(boardId, list.id)}
                  className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <X size={16} className="mr-2" />
                  Delete List
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="p-2 flex-1 overflow-y-auto">
        <DndContext 
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={list.cards.map(card => card.id)}
            strategy={verticalListSortingStrategy}
          >
            {list.cards.map((card) => (
              <CardItem 
                key={card.id} 
                card={card} 
                listId={list.id}
                boardId={boardId}
              />
            ))}
          </SortableContext>
        </DndContext>
        
        {isAdding ? (
          <div className="bg-white dark:bg-gray-700 p-3 rounded-md shadow mb-2">
            <input
              type="text"
              placeholder="Card title"
              value={newCardTitle}
              onChange={(e) => setNewCardTitle(e.target.value)}
              className="w-full mb-2 p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent"
              autoFocus
            />
            <textarea
              placeholder="Description"
              value={newCardDescription}
              onChange={(e) => setNewCardDescription(e.target.value)}
              className="w-full mb-2 p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent resize-none"
              rows={2}
            />
            <div className="mb-3">
              <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">Due Date</label>
              <input
                type="date"
                value={newCardDueDate}
                onChange={(e) => setNewCardDueDate(e.target.value)}
                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setIsAdding(false)}
                className="px-3 py-1 text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCard}
                className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
              >
                Add
              </button>
            </div>
          </div>
        ) : (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsAdding(true)}
            className="w-full mt-2 p-2 flex items-center justify-center text-gray-600 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 rounded-md transition-colors"
          >
            <Plus size={16} className="mr-1" />
            <span>Add a card</span>
          </motion.button>
        )}
      </div>
    </div>
  );
};

export default BoardList;
