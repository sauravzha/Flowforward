
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import Tasks from "./pages/dashboard/Tasks";
import Board from "./pages/board/Board";
import NotFound from "./pages/NotFound";
import Chat from "./pages/dashboard/Chat";
import Docs from "./pages/dashboard/Docs";
import Calendar from "./pages/dashboard/Calendar";
import Ai from "./pages/dashboard/Ai";
import TimeTracking from "./pages/dashboard/TimeTracking";
import Dashboards from "./pages/dashboard/Dashboards";
import Forms from "./pages/dashboard/Forms";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dashboard/tasks" element={<Tasks />} />
        <Route path="/dashboard/chat" element={<Chat />} />
        <Route path="/dashboard/docs" element={<Docs />} />
        <Route path="/dashboard/calendar" element={<Calendar />} />
        <Route path="/dashboard/ai" element={<Ai />} />
        <Route path="/dashboard/time-tracking" element={<TimeTracking />} />
        <Route path="/dashboard/dashboards" element={<Dashboards />} />
        <Route path="/dashboard/forms" element={<Forms />} />
        <Route path="/board/:id" element={<Board />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
